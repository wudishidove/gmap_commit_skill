# LUKE'S LOBSTER／ルークス ロブスター（澀谷／原宿／表參道、新宿）

## 篩選判斷

- 正式店名：LUKE'S LOBSTER（ルークス ロブスター）—— 源自紐約的緬因龍蝦堡（Lobster Roll）專門店，日本由 BAYCREW'S／Flavorworks 營運。
- 是否仍在營業：**品牌仍在營業**。對照 Flavorworks 官方現役店舖頁與 BAYCREW'S 官方店舖一覧，**東京現役分店共 4 家**：表参道キャットストリート店、原宿／表参道エアストリーム店、渋谷Park Street店、新宿サザンテラス店。已閉店者（新宿EAST店、銀座店、渋谷ストリーム店、舊表参道店移轉）見「補充判斷」。
- 列入區域：澀谷／原宿／表參道（規則 2 第 2 區）、新宿（規則 2 第 1 區）
- 列入理由：4 家現役分店分別緊鄰 Cat Street／表參道、明治神宮前／竹下通、澀谷十字路口／Center Gai／宮下公園、NEWoMan 新宿／LUMINE 新宿，皆在景點步行 20 分鐘內（規則 2／3）。
- 不列入分店／相關店：京都四条店、りんくうプレミアムアウトレット店（皆非東京 13 區）；舊表参道店（已移轉至貓街店）；新宿EAST店、銀座店、渋谷ストリーム店（皆已閉店）；阪急百貨期間限定／POP UP（關西為主、東京無常設櫃位）。詳見補充判斷。
- 成田機場是否有常設店：**無**（成田機場內無 LUKE'S LOBSTER 常設店）。

## 餐廳／購買資訊表

| 分店 | 時間 | 公休 | Google Maps | Google 評論 | 食べログ |
|---|---|---|---|---|---|
| 表参道キャットストリート店（渋谷区神宮前5-25-4 BARCAビル1F） | 11:00–20:00（食べログ另記平日11:00–21:00、週末10:00–21:00，以現場為準） | 不定休 | [Google Maps 搜尋連結](https://www.google.com/maps/search/?api=1&query=LUKE%27S%20LOBSTER%20%E8%A1%A8%E5%8F%82%E9%81%93%E3%82%AD%E3%83%A3%E3%83%83%E3%83%88%E3%82%B9%E3%83%88%E3%83%AA%E3%83%BC%E3%83%88%E5%BA%97%20%E6%9D%B1%E4%BA%AC%E9%83%BD%E6%B8%8B%E8%B0%B7%E5%8C%BA%E7%A5%9E%E5%AE%AE%E5%89%8D5-25-4%20BARCA%E3%83%93%E3%83%AB1F) | 未查到可驗證（非Google參考：Yahoo!地圖 4.06、NAVITIME 4.0／357件，非Google） | 3.40／145件　[食べログ頁](https://tabelog.com/tokyo/A1306/A130601/13255446/) |
| 原宿エアストリーム店（＝表参道エアストリーム店）（渋谷区神宮前4-26-18，Airstream 餐車型，2024/10/1 OPEN） | 11:00–21:00（官網；食べログ部分頁記 10:00–21:00，以官網為準）每日營業 | 無休／不定休 | [Google Maps 搜尋連結](https://www.google.com/maps/search/?api=1&query=LUKE%27S%20LOBSTER%20%E5%8E%9F%E5%AE%BF%E3%82%A8%E3%82%A2%E3%82%B9%E3%83%88%E3%83%AA%E3%83%BC%E3%83%A0%E5%BA%97%20%E6%9D%B1%E4%BA%AC%E9%83%BD%E6%B8%8B%E8%B0%B7%E5%8C%BA%E7%A5%9E%E5%AE%AE%E5%89%8D4-26-18) | 未查到可驗證（非Google參考：Yahoo!地圖 3.62，非Google） | 3.05／17件　[食べログ頁](https://tabelog.com/tokyo/A1306/A130601/13301987/) |
| 渋谷Park Street店（渋谷区神南1-15-5 神南プラザビル1F） | 約 8:30–19:30（官方頁亦載 8:30–19:00，部分平台 11:00–20:00，以官網／現場為準） | 不定休 | [Google Maps 搜尋連結](https://www.google.com/maps/search/?api=1&query=LUKE%27S%20LOBSTER%20%E6%B8%8B%E8%B0%B7Park%20Street%E5%BA%97%20%E6%9D%B1%E4%BA%AC%E9%83%BD%E6%B8%8B%E8%B0%B7%E5%8C%BA%E7%A5%9E%E5%8D%971-15-5%20%E7%A5%9E%E5%8D%97%E3%83%97%E3%83%A9%E3%82%B6%E3%83%93%E3%83%AB1F) | 未查到可驗證（非Google參考：LINE PLACE 4.0／78件、Retty 推薦度79%，非Google） | 3.28／256件　[食べログ頁](https://tabelog.com/tokyo/A1303/A130301/13193589/) |
| 新宿サザンテラス店（渋谷区代々木2-2-1 新宿サザンテラス2F） | 08:00–21:00（L.O. 20:45） | 不定休（依設施） | [Google Maps 搜尋連結](https://www.google.com/maps/search/?api=1&query=LUKE%27S%20LOBSTER%20%E6%96%B0%E5%AE%BF%E3%82%B5%E3%82%B6%E3%83%B3%E3%83%86%E3%83%A9%E3%82%B9%E5%BA%97%20%E6%9D%B1%E4%BA%AC%E9%83%BD%E6%B8%8B%E8%B0%B7%E5%8C%BA%E4%BB%A3%E3%80%85%E6%9C%A82-2-1%20%E6%96%B0%E5%AE%BF%E3%82%B5%E3%82%B6%E3%83%B3%E3%83%86%E3%83%A9%E3%82%B92F) | 未查到可驗證（非Google參考：Yahoo!地圖 3.62，非Google） | 3.33／272件　[食べログ頁](https://tabelog.com/tokyo/A1304/A130401/13239158/) |

> 註（規則 5）：4 家分店均無法擷取 Google Maps 該分店確切星等／人數，依規則寫「未查到可驗證」，並標明 Yahoo!地圖／NAVITIME／LINE PLACE／Retty 為非 Google 來源，僅供參考，不冒充 Google 分數。

## 網路上推薦吃這家的理由

- 品牌特色：2009 年發跡於紐約曼哈頓的龍蝦堡專門店，主打緬因州龍蝦肉夾入奶油烤過的開邊圓麵包，美式原汁原味；日本由 BAYCREW'S／Flavorworks 引進。
- 主要賣點：Lobster Roll（龍蝦堡，分一般／US 加大尺寸）為招牌；另有 Crab Roll（蟹）、Shrimp Roll（蝦）、Half & Half 與三味的 LUKE'S Trio，配蛤蜊巧達濃湯、薯條。貓街店有眺望 Cat Street 的露天 Terrace 席；原宿店為 Airstream 銀色餐車造型。
- 台灣實訪／部落格討論：表參道／原宿散步路線常見「邊走邊吃」名點，討論集中份量足、好吃但「CP 值偏高、價位略貴」。
- 日本實訪／媒體討論：OMOHARAREAL、aumo、えん食べ、るるぶ&more.、PR TIMES、レッツエンジョイ東京等多家媒體報導；食べログ口コミ提到龍蝦份量足、奶油醬好吃，亦有「單價偏高、客群多為外國觀光客」之評。
- Instagram 非官方實訪：龍蝦堡剖面、餐車外觀與 Cat Street 街景為常見打卡素材（IG 非官方實訪照為主）。
- Threads公開實訪：未查到穩定可驗證的公開實訪串。
- 定位：觀光客名店／新話題店（紐約人氣品牌的東京散步外帶龍蝦堡店）。

## 排隊狀況

判斷：**因分店而異**——表参道キャットストリート店為尖峰排隊；渋谷Park Street店通常不用排（尖峰短排）；原宿エアストリーム店、新宿サザンテラス店未查到穩定排隊資訊。

- 實訪等待紀錄：貓街店 aumo 實訪「平日就有 6～7 組在排」，週末更多；渋谷Park Street店多筆實訪「幾乎不用排」，週日午後可直接入座。
- 尖峰時段：週末、午餐（約 12:00–14:00）及午後觀光人潮時段。
- 完售風險：未查到穩定完售情報（KING LOBSTER ROLL 等大份／話題品項屬數量限定性質）。
- 等待時間估計：貓街店平日尖峰約 6～7 組（約 15～30 分），週末更久；渋谷Park Street店離峰 0～5 分、尖峰 5～15 分（多為現點現做取餐等待）；原宿／新宿離峰多半即點即取。

## 可否預約／取號／外帶

| 項目 | 判斷 | 備註 |
|---|---|---|
| 座位預約 | **不可預約／無座位預約（現場候位）** | 表参道キャットストリート店（約8席）、原宿エアストリーム店、渋谷Park Street店食べログ均標「予約不可」；新宿サザンテラス店食べログ列電話 03-6773-0423，惟未查到此分店之 TableCheck／Hot Pepper／ぐるなび／EPARK／官方線上訂位專頁，實務以現場候位＋電話為主。4 家皆無對外可點擊席位訂位連結，故不放連結。 |
| 是否只能綁套餐 | 否 | 可單點龍蝦堡／蟹堡／蝦堡，可加湯、薯條或選套餐，無強制套餐。 |
| 席のみ | 不適用 | 非「席のみ」預約制，屬點餐取餐型；亦大量供外帶。 |
| 取號／整理券 | 因店而異 | 渋谷Park Street店先付款領號碼牌、叫號取餐；其餘多為櫃台排隊點餐，未見整理券制。 |
| 外帶 | 可 | 全分店皆可外帶（テイクアウト），以邊走邊吃為主力之一。 |
| 店頭取貨 | 部分可 | 渋谷Park Street店官網提供 Local Pick-up（線上下單、店頭取貨）；其餘為現場點餐取餐。 |
| 官方通販 | 品牌層級有 | LUKE'S LOBSTER／Flavorworks 曾推居家龍蝦堡 KIT 等通販，屬品牌通販非各分店業態（規則 6 分開）。 |
| 第三方平台 | 資訊頁為主 | 收錄於食べログ／ぐるなび／Retty／LINE PLACE 等，皆為店家資訊頁，非座位訂位（各分店不可訂位）。 |

## 討論度前 3 高

| 排名 | 正式日文品項 | 中文名稱 | 討論／推薦理由 | 供應條件 | 實訪照片／介紹文(可點擊連結文字) |
|---|---|---|---|---|---|
| 1 | ロブスターロール（レギュラー／US サイズ） | 龍蝦堡（一般／US 加大尺寸） | 招牌中招牌，討論度壓倒性第一。緬因龍蝦肉＋奶油烤麵包、淋檸檬奶油醬，US 尺寸「一份約 5 隻龍蝦肉」肉塊飽滿彈牙，為排隊主因，被多數實訪列為必點 | 每天，售完為止 | [えん食べ 表参道實食（媒體實訪照）](https://entabe.jp/news/gourmet/8139/tried-lobster-roll-at-lukes-omotesando)、[DanielFoodDiary 實訪（部落格實訪照）](https://danielfooddiary.com/2017/04/08/lukelobstertokyo/) |
| 2 | ロブスター＆シュリンプロール／ハーフ&ハーフ（LUKE'S Trio） | 龍蝦＆蝦堡／一半一半組合（三味組合） | 討論度第二，可「一次吃多種口味」、CP 與拍照話題性高，台港日部落格與 IG 常見「龍蝦＋蝦／蟹食べ比べ」分享，適合分食 | 每天，售完為止 | [eatandtravelwithus 原宿實訪（部落格實訪照）](https://www.eatandtravelwithus.com/2019/03/lukes-lobster-harajuku-tokyo/)、[aumo 介紹文（媒體照片）](https://aumo.jp/articles/20921) |
| 3 | シュリンプロール／クラムチャウダー | 蝦肉堡／蛤蜊巧達濃湯 | 蝦肉堡為龍蝦堡外最常被當「平價替代」討論之品項；蛤蜊巧達濃湯為實訪最常搭配的副餐，被形容滿滿蛤蜊馬鈴薯、暖胃，冬天與套餐討論度上升 | 每天（濃湯為固定副餐），售完為止 | [レッツエンジョイ東京 新宿店實食レポ（媒體實訪照）](https://www.enjoytokyo.jp/article/110203/) |

> 註（規則 8／11）：以上依食べログ／媒體／台日部落格／IG 反覆出現度排序；KING LOBSTER ROLL（原宿店開幕話題、約一般 5 倍、¥10,000）為數量限定話題品項但討論度低於上述三組。連結均為媒體照片／部落格實訪照，非官方原始實拍，依規則 11 標註。

## 補充判斷

| 店名／項目 | 不列入原因 |
|---|---|
| **LUKE'S LOBSTER 新宿EAST店（新宿区新宿3-17-20）** | **已閉店（永久歇業）**。食べログ標示「This restaurant is permanently closed」（3.15／13件，[食べログ頁](https://tabelog.com/tokyo/A1304/A130401/13227806/)）；Flavorworks／BAYCREW'S 官方現役清單已無此店。NAVITIME／部分店舖一覧殘留過期條目，不代表營業。規則 1 排除，不列為可去店。 |
| **LUKE'S LOBSTER 銀座店（中央区銀座3-4-16）** | **已閉店**。食べログ標題標【閉店】（[食べログ頁](https://tabelog.com/tokyo/A1301/A130101/13223627/)），曾為日本國內最大路面店。落在規則 2 第 5 區範圍，明確標註已閉店避免誤認為現役分店。規則 1 排除。 |
| LUKE'S LOBSTER 渋谷ストリーム店 | 已於 2020/11/30 閉店，食べログ標【閉店】，規則 1 排除（與現役渋谷Park Street店為不同分店，勿混淆）。 |
| LUKE'S LOBSTER 表参道店（舊店／初代日本一號店） | 2015 年日本首店，2021/2/1 已移轉至現表参道キャットストリート店，食べログ標 Relocated，與現役貓街店重複，不重複列入（規則 1／6）。 |
| LUKE'S LOBSTER 京都四条店 | 位於京都市，不在東京 13 區景點 20 分鐘內（規則 2／3）。 |
| LUKE'S LOBSTER りんくうプレミアムアウトレット店 | 位於大阪府泉佐野市，不在東京 13 區內（規則 2／3）。 |
| 阪急百貨 期間限定／POP UP | 期間限定／POP UP（以關西為主、疑已結束），東京未見常設櫃位，規則 1 排除。 |
| Google 評論星等／人數（全 4 家現役分店） | 無法擷取 Google Maps 確切星等／評論數，依規則 5 寫「未查到可驗證」，僅附 Yahoo!地圖／NAVITIME／LINE PLACE／Retty 等非 Google 來源並標明，不冒充 Google 分數。 |

---

**資料來源（Sources）**
- [食べログ 表参道キャットストリート店](https://tabelog.com/tokyo/A1306/A130601/13255446/)
- [食べログ 原宿エアストリーム店](https://tabelog.com/tokyo/A1306/A130601/13301987/)
- [食べログ 渋谷Park Street店](https://tabelog.com/tokyo/A1303/A130301/13193589/)
- [食べログ 新宿サザンテラス店](https://tabelog.com/tokyo/A1304/A130401/13239158/)
- [食べログ 新宿EAST店（已閉店）](https://tabelog.com/tokyo/A1304/A130401/13227806/)
- [食べログ 銀座店（已閉店）](https://tabelog.com/tokyo/A1301/A130101/13223627/)
- [Luke's Lobster 官網 Harajuku Airstream](https://lukeslobster.com/pages/harajuku-airstream)
- [Luke's Lobster 官網 Shibuya Park Street](https://lukeslobster.com/pages/shibuya-park-street)
- [BAYCREW'S STORE 店舗一覧（brand=0041）](https://baycrews.jp/store/list?brand=0041)
- [Flavorworks 官方 Luke's Lobster 現役店舖頁](https://www.flavorworks.co.jp/en/lukes-lobster)
- [OMOHARAREAL 表参道店移轉貓街店報導](https://www.omoharareal.com/navi/news/detail/2515)
- [PR TIMES 原宿エアストリーム店 10/1 OPEN](https://prtimes.jp/main/html/rd/p/000001903.000011498.html)
- [aumo 原宿人氣龍蝦堡實訪](https://aumo.jp/articles/20921)
- [えん食べ 表参道店ロブスターロール実食](https://entabe.jp/news/gourmet/8139/tried-lobster-roll-at-lukes-omotesando)
- [DanielFoodDiary Luke's Lobster Tokyo](https://danielfooddiary.com/2017/04/08/lukelobstertokyo/)
- [eatandtravelwithus Luke's Lobster Harajuku](https://www.eatandtravelwithus.com/2019/03/lukes-lobster-harajuku-tokyo/)
- [レッツエンジョイ東京 新宿店実食レポ](https://www.enjoytokyo.jp/article/110203/)
- [るるぶ&more. 表参道 LUKE'S LOBSTER](https://rurubu.jp/andmore/article/13214)

> 提醒：各店營業時間於不同平台略有出入（已於表中並列並提醒以官網／現場為準）；出發前建議以官網或致電確認（渋谷Park Street店 03-5456-6957、新宿サザンテラス店 03-6773-0423）。
