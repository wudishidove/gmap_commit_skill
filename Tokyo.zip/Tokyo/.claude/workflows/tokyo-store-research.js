export const meta = {
  name: 'tokyo-store-research',
  description: '依 CLAUDE.md 規則並行查詢東京餐廳／伴手禮店家，最後由收尾 agent 做完整性檢查（特別抓百貨櫃位漏網分店）',
  whenToUse: '使用者給一個店名／品牌名，要整理成 CLAUDE.md 固定格式時。建議 args 傳 { store, spec }，spec 為主流程讀入的 CLAUDE.md 全文（唯一規格來源）；亦相容只傳店名字串。',
  phases: [
    { title: '載入規格', detail: '取得 CLAUDE.md 規格（優先 args.spec，否則 agent 讀檔）', model: 'sonnet' },
    { title: '分店探索', detail: '5 路並行：官網／食べログ／Google Maps／百貨櫃位／部落格社群', model: 'sonnet' },
    { title: '景點篩選', detail: '依 13 區 20 分鐘規則篩出可列入分店', model: 'sonnet' },
    { title: '逐店詳查', detail: '每家可列入分店並行查營業狀態／時間／評分／地圖；Google 評論用 gmap skill 抓真實星等/評論數', model: 'sonnet' },
    { title: '品項討論度', detail: '討論度前 3 高品項', model: 'sonnet' },
    { title: '收尾完整性檢查', detail: '比對官方店舖清單，專抓百貨／商業設施漏網櫃位（檢查用 opus，補查詳查用 sonnet＋gmap）' },
    { title: '彙整輸出', detail: '產出 CLAUDE.md 固定 markdown 格式', model: 'opus' },
  ],
}

// ---- args ----
// 支援兩種傳法：
//   1) 字串：店名（向後相容）
//   2) 物件：{ store, spec }  ← 建議。spec 為 CLAUDE.md 全文，由主流程讀檔後傳入。
const STORE = (typeof args === 'string' && args.trim())
  ? args.trim()
  : (args && args.store) ? String(args.store).trim() : null
const SPEC = (args && typeof args === 'object' && args.spec) ? String(args.spec) : null
if (!STORE) {
  throw new Error('請以 args 傳入店名／品牌名，例如 args: "つきじ宮川本廛" 或 { store, spec }')
}

// ---- 規格來源：CLAUDE.md（唯一真相來源）----
// 刻意不在此複製 13 區清單／規則／輸出格式，避免漂移。
// 取得順序：1) 優先用 args.spec（主流程已讀好，最快）；
//          2) 沒有就由 agent 用 Read 工具直接讀 CLAUDE.md。
// workflow 腳本本身不能讀檔，但 agent 有 Read 工具 →
// 即使在乾淨 session 裸跑（只給店名）也一定拿得到完整規格，不會發生少規格的情況。
const CLAUDE_MD_PATH = 'E:\\claude\\Tokyo\\CLAUDE.md'
phase('載入規格')
let SPEC_TEXT = SPEC
if (!SPEC_TEXT) {
  log('未由 args.spec 取得規格 → 由 agent 直接讀取 CLAUDE.md')
  SPEC_TEXT = await agent(
    `用 Read 工具讀取檔案 ${CLAUDE_MD_PATH}，把全文一字不漏、原樣回傳（純文字；不要摘要、不要加任何說明或前後綴）。`,
    { label: '載入CLAUDE.md規格', phase: '載入規格', model: 'sonnet' }
  )
}
if (!SPEC_TEXT || SPEC_TEXT.length < 200) {
  throw new Error('無法取得 CLAUDE.md 規格（args.spec 未傳且讀檔失敗）。請確認 ' + CLAUDE_MD_PATH + ' 存在且可讀。')
}
const RULES_BLOCK = `【以下為完整工作規則與固定輸出格式，來自 CLAUDE.md，為唯一真相來源，一切判斷與輸出格式皆以此為準】\n\n${SPEC_TEXT}`

// 容易被漏的「百貨／商業設施」櫃位錨點（落在 13 區範圍內）
const DEPACHIKA = [
  '新宿伊勢丹', '伊勢丹新宿', 'LUMINE新宿', 'NEWoMan新宿', '京王百貨店新宿', '小田急新宿', '高島屋新宿',
  '西武池袋本店', '東武百貨店池袋', 'Sunshine City池袋',
  '松屋浅草', 'EKIMISE浅草', '東京Solamachi晴空塔', '東武百貨店',
  '松屋銀座', '銀座三越', 'GINZA SIX', '銀座松屋',
  '日本橋三越', '日本橋高島屋', 'COREDO室町',
  '大丸東京', '東京車站一番街', 'GRANSTA東京', 'ecute東京', 'KITTE丸之內',
  '澀谷東急', '澀谷Scramble Square', '東急百貨', 'atre吉祥寺',
  '上野松坂屋', 'ecute上野', 'atre上野', '成田機場第1/第2/第3航廈',
]

// gmap skill：用 puppeteer 連系統 Chrome 真渲染 Google 地圖頁讀真實星等/評論數。
// node_modules 已安裝在該資料夾，require 由腳本所在目錄解析，任何 cwd 都可跑。
const GMAP_JS = 'C:\\Users\\Wolfsbane\\.claude\\skills\\gmap_commit_skill\\fetch_maps.js'
const gmapHint = (q) =>
  `- Google 評論（規則5，務必用 gmap skill 抓「此分店」真實數據）：` +
  `用 Bash 執行 \`node "${GMAP_JS}" "${q}"\`，解析 stdout 的 JSON（欄位 rating 與 reviewCount），` +
  `寫成「X.X星／N人」（例：4.2星／318人）。腳本報錯或查無資料時，才退回規則5一般查法` +
  `（非 Google 來源要標明來源；真的查不到「此分店本身」才寫「未查到可驗證」）。`

// ---- schemas ----
const BRANCH_LIST = {
  type: 'object',
  additionalProperties: false,
  required: ['branches'],
  properties: {
    branches: {
      type: 'array',
      items: {
        type: 'object',
        additionalProperties: false,
        required: ['name', 'venue', 'status', 'source'],
        properties: {
          name: { type: 'string', description: '官方分店全名，例如「つきじ宮川本廛 西武池袋本店」' },
          venue: { type: 'string', description: '所在百貨/設施/地點，無則填地址或地名' },
          status: { type: 'string', description: '營業/閉店/休業/移轉/期間限定結束/未查到，能寫到的都寫' },
          source: { type: 'string', description: '此分店資訊來源（官網店舖一覧/食べログ/Google Maps/百貨官網/部落格…）' },
        },
      },
    },
  },
}

const FILTER_RESULT = {
  type: 'object',
  additionalProperties: false,
  required: ['included', 'excluded'],
  properties: {
    included: {
      type: 'array',
      items: {
        type: 'object',
        additionalProperties: false,
        required: ['name', 'area'],
        properties: {
          name: { type: 'string' },
          area: { type: 'string', description: '列入的 13 區之一 + 最近景點' },
          venue: { type: 'string' },
        },
      },
    },
    excluded: {
      type: 'array',
      items: {
        type: 'object',
        additionalProperties: false,
        required: ['name', 'reason'],
        properties: { name: { type: 'string' }, reason: { type: 'string' } },
      },
    },
  },
}

const COMPLETENESS = {
  type: 'object',
  additionalProperties: false,
  required: ['missing', 'issues', 'verdict'],
  properties: {
    missing: {
      type: 'array',
      description: '應列入（落在 13 區/東京車站/成田機場 20 分鐘內）但前面流程漏掉的分店',
      items: {
        type: 'object',
        additionalProperties: false,
        required: ['name', 'venue', 'area', 'evidence'],
        properties: {
          name: { type: 'string' },
          venue: { type: 'string' },
          area: { type: 'string' },
          evidence: { type: 'string', description: '證據連結或來源，說明確實存在且在範圍內' },
        },
      },
    },
    issues: {
      type: 'array',
      description: '其他規則違反：營業狀態沒查證、評分亂填、品牌混列、圖片來源沒誠實標註等',
      items: { type: 'string' },
    },
    verdict: { type: 'string', description: 'PASS（無漏網、無問題）或 NEEDS_FIX（有漏網或問題）' },
  },
}

// ---- Phase 1：分店探索（多路並行，每路用不同角度，互相看不到）----
phase('分店探索')
const discoveryAngles = [
  {
    label: '官網店舖一覧',
    prompt: `查「${STORE}」的官方網站「店舖一覧 / 店舗一覧 / 取扱店 / Shop List」頁。列出官網列出的【全部】分店（不限東京），逐一給官方分店全名與所在地。特別注意：百貨地下街/櫃位常以「○○ 百貨店名 店」形式列出，不要漏。`,
  },
  {
    label: '食べログ分店',
    prompt: `在食べログ搜尋「${STORE}」，列出所有同品牌分店頁（注意分辨本店/分店/姐妹店/同集團，不要把不同品牌混進來）。每家給分店名與所在地。`,
  },
  {
    label: 'Google Maps 分店',
    prompt: `用 Google Maps / 網路搜尋「${STORE}」品牌在東京都內的所有據點，列出分店名與所在地點（含百貨櫃位）。`,
  },
  {
    label: '百貨/商業設施櫃位',
    prompt: `「${STORE}」很可能在百貨公司或車站商業設施內設櫃，這類分店最常被漏。請逐一搜尋下列設施是否有「${STORE}」設櫃，有的列出官方分店全名：\n${DEPACHIKA.join('、')}\n搜尋語法例如「${STORE} 西武池袋」「${STORE} 松屋浅草」「${STORE} 大丸東京」。`,
  },
  {
    label: '部落格/社群實訪',
    prompt: `搜尋台灣與日本部落格、IG、Threads、媒體文章中提到的「${STORE}」分店（含期間限定/POP UP），列出曾被實訪或提到的分店名與地點。標出疑似已結束的期間限定。`,
  },
]

const discovered = (await parallel(
  discoveryAngles.map((a) => () =>
    agent(a.prompt + '\n\n回覆繁體中文。只回報你有實際搜尋到證據的分店，查不到就回空陣列，不要臆測。', {
      label: a.label,
      phase: '分店探索',
      model: 'sonnet',
      schema: BRANCH_LIST,
    })
  )
)).filter(Boolean).flatMap((r) => r.branches || [])

// 依正規化店名去重（去空白/全半形差異）
const norm = (s) => String(s || '').replace(/[\s　]/g, '').replace(/[（）()]/g, '').toLowerCase()
const branchMap = new Map()
for (const b of discovered) {
  const k = norm(b.name)
  if (!k) continue
  if (!branchMap.has(k)) branchMap.set(k, { ...b, sources: new Set([b.source]) })
  else branchMap.get(k).sources.add(b.source)
}
const allBranches = [...branchMap.values()]
log(`分店探索：合併去重後共 ${allBranches.length} 家候選分店`)

// ---- Phase 2：景點篩選（13 區 20 分鐘規則）----
phase('景點篩選')
const filtered = await agent(
  `這是「${STORE}」候選分店清單：\n${allBranches.map((b) => `- ${b.name}（${b.venue || '?'}｜狀態:${b.status || '?'}）`).join('\n')}\n\n` +
  `依以下規則篩選（回覆繁體中文）：\n` +
  `規則 2：只列入「13 區景點步行/開車/大眾運輸約 20 分鐘內」的分店；其餘排除。\n` +
  `規則 3：成田機場只列機場內分店。\n` +
  `規則 1：閉店/休業/移轉/期間限定已結束者排除，並在 excluded 註明。\n\n` +
  `${RULES_BLOCK}\n\n` +
  `included 每家標出列入的區與最近景點；excluded 每家寫不列入原因。判斷不確定距離時保守列入並註明需再確認。`,
  { phase: '景點篩選', model: 'sonnet', schema: FILTER_RESULT }
)
log(`景點篩選：列入 ${filtered.included.length} 家、排除 ${filtered.excluded.length} 家`)

// ---- Phase 3 + 4：逐店詳查（pipeline）+ 品項討論度（並行）----
phase('逐店詳查')
const detailPromises = filtered.included.map((br) =>
  agent(
    `查「${br.name}」（${br.venue || ''}，${br.area}）的詳細資訊，回覆繁體中文，逐項給：\n` +
    `- 是否仍在營業（規則1，務必查證）\n- 營業時間、公休\n` +
    `- Google Maps 連結（規則4：優先 maps.app.goo.gl 短連結；否則 https://www.google.com/maps/search/?api=1&query= 加「店名+分店+完整地址」做 URL 編碼，這欄一定要做得出來，不寫「未查到」）\n` +
    `${gmapHint(br.name)}\n` +
    `- 食べログ（規則5：寫「X.XX／N件」並附該分店食べログ頁連結；查不到才寫「未查到可驗證」）\n` +
    `- 排隊狀況（規則9：常態排隊/尖峰排隊/通常不用排/未查到，附等待時間估計）\n` +
    `- 座位預約（規則10）：可/不可；可訂位的話一定附「此分店」的訂位連結【完整網址】（TableCheck／Hot Pepper／ぐるなび／食べログ／EPARK／官方擇一），並註明用的是哪個平台；不可訂位或無座位要寫明「不可預約／無座位（現場候位）」\n` +
    `- 其他：是否只能綁套餐／席のみ／取號整理券／外帶／店頭取貨／官方通販／第三方平台（規則10）\n` +
    `Google Maps 與評分欄查不到也不要亂填，依規則 4／5 處理。\n\n${RULES_BLOCK}`,
    { label: br.name, phase: '逐店詳查', model: 'sonnet' }
  ).then((text) => ({ branch: br, detail: text }))
)

phase('品項討論度')
const itemsPromise = agent(
  `整理「${STORE}」討論度前 3 高的品項（規則7：依食べログ、Google 評論照片、台日實訪、IG/Threads 非官方實訪反覆出現度判斷，不只列官方推薦）。\n` +
  `每項給（規則8）：正式日文品項名、中文名、討論/推薦理由、供應條件（每天/平日/週末/午餐/晚餐/季節/數量限定/未查到）、實訪照片或介紹文連結（規則11：若只有官方照要標「官方照片，不是實訪照」）。回覆繁體中文。`,
  { label: '討論度前3', phase: '品項討論度', model: 'sonnet' }
)

const [details, itemsInfo] = await Promise.all([Promise.all(detailPromises), itemsPromise])

// ---- Phase 5：收尾完整性檢查（核心：抓百貨櫃位漏網分店）----
phase('收尾完整性檢查')
const includedNames = filtered.included.map((b) => b.name)
const checkResult = await agent(
  `你是收尾完整性檢查員。針對「${STORE}」，前面流程「列入」了這些分店：\n${includedNames.map((n) => `- ${n}`).join('\n') || '（無）'}\n\n` +
  `你的任務是【獨立重查】，找出任何「落在下列 13 區 / 東京車站 / 成田機場 20 分鐘內，但上面清單漏掉」的分店。\n\n` +
  `重點：百貨公司與車站商業設施內的櫃位最常被漏，因為它們常被歸在百貨名稱下、不以獨立店名出現。請務必逐一重新搜尋下列設施是否有「${STORE}」設櫃：\n${DEPACHIKA.join('、')}\n` +
  `搜尋語法例如「${STORE} 西武池袋」「${STORE} 松屋浅草」。同時對照官方「店舗一覧」清單與上面列入清單做差集。\n\n` +
  `${RULES_BLOCK}\n\n` +
  `missing：列出漏掉且應列入（落在 13 區/東京車站/成田機場 20 分鐘內）的分店（附證據連結）。issues：列出其他規則違反（營業狀態未查證、評分亂填、品牌混列、圖片來源未誠實標註等）。verdict：PASS 或 NEEDS_FIX。回覆繁體中文，沒有證據不要臆測。`,
  { phase: '收尾完整性檢查', model: 'opus', schema: COMPLETENESS }
)
log(`收尾檢查：verdict=${checkResult.verdict}，漏網 ${checkResult.missing.length} 家，問題 ${checkResult.issues.length} 項`)

// 對漏網分店補做詳查，併回 details
let recovered = []
if (checkResult.missing.length) {
  log(`補查漏網分店：${checkResult.missing.map((m) => m.name).join('、')}`)
  recovered = (await parallel(
    checkResult.missing.map((m) => () =>
      agent(
        `查「${m.name}」（${m.venue || ''}，${m.area}）詳細資訊，回覆繁體中文，逐項給：是否仍在營業、營業時間/公休、Google Maps 連結（規則4：優先 maps.app.goo.gl 短連結，否則 https://www.google.com/maps/search/?api=1&query= 加店名+完整地址做 URL 編碼，不寫「未查到」）、食べログ（規則5：X.XX／N件附連結，查不到寫「未查到可驗證」）、排隊狀況+等待估計、座位預約（可/不可，可訂位附「此分店」訂位連結完整網址並註明平台）、是否綁套餐/席のみ/取號/外帶/店頭取貨/通販/第三方平台。\n${gmapHint(m.name)}\n\n${RULES_BLOCK}`,
        { label: '補查:' + m.name, phase: '收尾完整性檢查', model: 'sonnet' }
      ).then((text) => ({ branch: { name: m.name, venue: m.venue, area: m.area }, detail: text, recovered: true }))
    )
  )).filter(Boolean)
}

const allDetails = [...details, ...recovered]

// ---- Phase 6：彙整輸出（CLAUDE.md 固定格式）----
phase('彙整輸出')
const final = await agent(
  `把「${STORE}」的研究結果整理成 CLAUDE.md 規定的固定 markdown 格式輸出（繁體中文）。\n\n` +
  `${RULES_BLOCK}\n\n` +
  `嚴格按上述 CLAUDE.md「固定輸出格式」的所有區塊與表格欄位輸出，逐條遵守規則 1~11。\n\n` +
  `=== 列入分店與詳查 ===\n${allDetails.map((d) => `【${d.branch.name}｜${d.branch.area || ''}${d.recovered ? '｜(收尾補回)' : ''}】\n${d.detail}`).join('\n\n')}\n\n` +
  `=== 排除分店 ===\n${filtered.excluded.map((e) => `- ${e.name}：${e.reason}`).join('\n')}\n\n` +
  `=== 討論度前3品項 ===\n${itemsInfo}\n\n` +
  `=== 收尾完整性檢查 ===\nverdict：${checkResult.verdict}\n漏網補回：${checkResult.missing.map((m) => m.name).join('、') || '無'}\n其他問題：${checkResult.issues.join('；') || '無'}\n\n` +
  `規則提醒：營業狀態要查證(規則1)、Google Maps 用 maps.app.goo.gl 或編碼 search 連結、Google 評論寫「X.X星／N人」(規則4/5)、品牌/姐妹店/期間限定要分清(規則6)、圖片來源誠實標註(規則11)、成田機場只列機場內(規則3)。\n` +
  `座位預約欄(規則10)：把各分店訂位連結寫成可點擊文字連結；多家共用同一連結就併在一起寫並只給一個連結，連結不同就逐家分開寫；不可訂位/無座位的分店寫明不放連結。`,
  { phase: '彙整輸出', model: 'opus' }
)

return {
  store: STORE,
  included: filtered.included,
  excluded: filtered.excluded,
  completeness: checkResult,
  recoveredBranches: recovered.map((r) => r.branch.name),
  markdown: final,
}
